<?php 

/**
 * config/database.php
 * Purpose: Database configuration and connection settings
 */

 return [
    'host' => 'localhost',
    'dbname' => 'order_management',
    'username' => 'root',
    'password' => '',
    'charset' => 'utf8mb4',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]
];

/**
 * class/Database.php
 * Purpose: Database connection handler using PDO

    class Database {
        private $host = "localhost";
        private $database_name = "bsgsfviz_roomie";
        private $username = "bsgsfviz_user";
        private $password = "giongtech@Abc";

        public $conn;

        public function getConnection(){
			 // set your default time-zone
	        date_default_timezone_set('Asia/Ho_Chi_Minh');
            $this->conn = null;
            try{
                $this->conn = new PDO("mysql:host=" . $this->host . ";dbname=" . $this->database_name, $this->username, $this->password);
                $this->conn->exec("set names utf8");
            }catch(PDOException $exception){
                echo "Database could not be connected: " . $exception->getMessage();
            }
            return $this->conn;
        }

		public function getConnectionV2(){
            //$this->conn = null;
            $this->conn = new mysqli($this->host, $this->username, $this->password, $this->database_name);
            if($this->conn->connect_error){
                die("Error failed to connect to MySQL: " . $this->conn->connect_error);
            }
            return $this->conn;
        }
    }  

     */
    
?>