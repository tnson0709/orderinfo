<?php
/**
 * api/orders.php
 * Purpose: Main orders endpoint for listing and creating orders
 */
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET,OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

 require_once '../config/database.php';
 require_once '../class/Database.php';
 require_once '../class/Order.php';
 require_once '../class/Response.php';
 
 // Handle CORS preflight
 if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
     Response::success();
 }
 
 try {
     $config = require '../config/database.php';
     $database = new Database($config);
     $order = new Order($database);
     
     $method = $_SERVER['REQUEST_METHOD'];
     
     switch ($method) {
         case 'GET':
             // Get paginated orders with search
             $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
             $limit = isset($_GET['limit']) ? max(1, intval($_GET['limit'])) : 10;
             $search = $_GET['search'] ?? '';
             
             $result = $order->getAll($page, $limit, $search);
             Response::success($result);
             
         case 'POST':
             // Create new order
             $input = json_decode(file_get_contents('php://input'), true);
             
             if (json_last_error() !== JSON_ERROR_NONE) {
                 Response::error('Invalid JSON input');
             }
             
             $newOrder = $order->create($input);
             
             if ($newOrder) {
                 Response::success($newOrder, 'Order created successfully');
             } else {
                 Response::error('Failed to create order');
             }
             
         default:
             Response::error('Method not allowed', 405);
     }
     
 } catch (Exception $e) {
     Response::error($e->getMessage(), 500);
 }
 
?>