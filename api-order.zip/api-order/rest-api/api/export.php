<?php
/**
 * api/export.php
 * Purpose: Export orders to CSV
 */
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

 require_once '../config/database.php';
 require_once '../class/Database.php';
 require_once '../class/Order.php';
 require_once '../class/Response.php';
 
 try {
     $config = require '../config/database.php';
     $database = new Database($config);
     $order = new Order($database);
     
     $method = $_SERVER['REQUEST_METHOD'];
     
     if ($method !== 'GET') {
         Response::error('Method not allowed', 405);
     }
     
     $filters = [
         'search' => $_GET['search'] ?? ''
     ];
     
     $orders = $order->exportToCSV($filters);
     
     // Set CSV headers
     header('Content-Type: text/csv; charset=utf-8');
     header('Content-Disposition: attachment; filename="orders_' . date('Y-m-d') . '.csv"');
     header('Access-Control-Allow-Origin: *');
     
     $output = fopen('php://output', 'w');
     
     // Add BOM for UTF-8
     fwrite($output, "\xEF\xBB\xBF");
     
     // Write headers
     if (!empty($orders)) {
         fputcsv($output, array_keys($orders[0]));
         
         // Write data
         foreach ($orders as $row) {
             // Convert licenseInfo from JSON to string for CSV
             if (isset($row['licenseInfo']) && is_string($row['licenseInfo'])) {
                 $row['licenseInfo'] = $row['licenseInfo'];
             }
             fputcsv($output, $row);
         }
     }
     
     fclose($output);
     
 } catch (Exception $e) {
     Response::error($e->getMessage(), 500);
 }
 
?>