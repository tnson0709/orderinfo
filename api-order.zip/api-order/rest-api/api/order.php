<?php
/**
 * api/order.php
 * Purpose: Single order endpoint for CRUD operations
 */
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST, GET, PUT, DELETE, OPTIONS");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

 require_once '../config/database.php';
 require_once '../class/Database.php';
 require_once '../class/Order.php';
 require_once '../class/Response.php';
 
 // Handle CORS preflight
 if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
     Response::success();
 }
 
 try {
     $config = require '../config/database.php';
     $database = new Database($config);
     $order = new Order($database);
     
     // Get order ID from URL (assuming URL like: /api/order/{id})
     $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
     $segments = explode('/', $path);
     $orderId = end($segments);
     
     if (empty($orderId)) {
         Response::error('Order ID is required');
     }
     
     $method = $_SERVER['REQUEST_METHOD'];
     
     switch ($method) {
         case 'GET':
             // Get single order
             $orderData = $order->getById($orderId);
             
             if ($orderData) {
                 Response::success($orderData);
             } else {
                 Response::notFound('Order not found');
             }
             
         case 'PUT':
             // Update order
             $input = json_decode(file_get_contents('php://input'), true);
             
             if (json_last_error() !== JSON_ERROR_NONE) {
                 Response::error('Invalid JSON input');
             }
             
             $updatedOrder = $order->update($orderId, $input);
             
             if ($updatedOrder) {
                 Response::success($updatedOrder, 'Order updated successfully');
             } else {
                 Response::error('Failed to update order');
             }
             
         case 'DELETE':
             // Delete order
             $affected = $order->delete($orderId);
             
             if ($affected > 0) {
                 Response::success(null, 'Order deleted successfully');
             } else {
                 Response::notFound('Order not found');
             }
             
         case 'POST':
             // Handle special actions (duplicate, confirm payment, provision)
             $input = json_decode(file_get_contents('php://input'), true);
             $action = $input['action'] ?? '';
             
             switch ($action) {
                 case 'duplicate':
                     $duplicated = $order->duplicate($orderId);
                     if ($duplicated) {
                         Response::success($duplicated, 'Order duplicated successfully');
                     } else {
                         Response::error('Failed to duplicate order');
                     }
                     
                 case 'confirm_payment':
                     $confirmed = $order->confirmPayment($orderId);
                     if ($confirmed) {
                         Response::success($confirmed, 'Payment confirmed successfully');
                     } else {
                         Response::error('Failed to confirm payment');
                     }
                     
                 case 'provision_resource':
                     $provisioned = $order->provisionResource($orderId);
                     if ($provisioned) {
                         Response::success($provisioned, 'Resource provisioned successfully');
                     } else {
                         Response::error('Failed to provision resource');
                     }
                     
                 default:
                     Response::error('Invalid action');
             }
             
         default:
             Response::error('Method not allowed', 405);
     }
     
 } catch (Exception $e) {
     Response::error($e->getMessage(), 500);
 }
 
?>