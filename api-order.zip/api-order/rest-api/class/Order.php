<?php
/**
 * class/Order.php
 * Purpose: Order business logic and database operations
 */

 class Order {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    /**
     * Get all orders with pagination and search
     */
    public function getAll($page = 1, $limit = 10, $search = '') {
        $offset = ($page - 1) * $limit;
        
        $where = '';
        $params = [];
        
        if (!empty($search)) {
            $where = "WHERE orderno LIKE ? OR productId LIKE ? OR customer_name LIKE ? OR email LIKE ?";
            $searchTerm = "%{$search}%";
            $params = array_fill(0, 4, $searchTerm);
        }
        
        // Get total count
        $countSql = "SELECT COUNT(*) as total FROM order_info $where";
        $countResult = $this->db->select($countSql, $params);
        $total = $countResult[0]['total'];
        
        // Get paginated data
        $sql = "SELECT * FROM order_info $where ORDER BY order_date DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        
        $orders = $this->db->select($sql, $params);
        
        return [
            'data' => $orders,
            'pagination' => [
                'page' => (int)$page,
                'limit' => (int)$limit,
                'total' => (int)$total,
                'pages' => ceil($total / $limit)
            ]
        ];
    }

    /**
     * Get order by ID
     */
    public function getById($id) {
        $sql = "SELECT * FROM order_info WHERE order_info_Id = ?";
        $result = $this->db->select($sql, [$id]);
        
        if (empty($result)) {
            return null;
        }
        
        return $result[0];
    }

    /**
     * Get next order number (auto-increment)
     */
    public function getNextOrderNo() {
        $sql = "SELECT MAX(CAST(REPLACE(orderno, 'ORD', '') AS UNSIGNED)) as max_no FROM order_info WHERE orderno REGEXP '^[0-9]+$' OR orderno LIKE 'ORD%'";
        $result = $this->db->select($sql);
        
        $maxNo = $result[0]['max_no'] ?? 0;
        $nextNo = $maxNo + 1;
        
        return str_pad($nextNo, 6, '0', STR_PAD_LEFT);
    }

    /**
     * Create new order
     */
    public function create($data) {
        // Validate required fields
        $required = ['productId', 'packcode'];
        foreach ($required as $field) {
            if (empty($data[$field])) {
                throw new Exception("Field {$field} is required");
            }
        }
        
        // Generate order info
        $orderId = $this->generateUUID();
        $orderNo = $data['orderno'] ?? $this->getNextOrderNo();
        
        $sql = "INSERT INTO order_info (
            order_info_Id, orderno, productId, packcode, licenseInfo, order_date,
            customer_name, customer_address, customer_type, taxcode, identity_code,
            tel, email, note, amount, payment_status, payment_tran_no, payment_type,
            payment_date, resource_status, partner_code, employee_code
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $params = [
            $orderId,
            $orderNo,
            $data['productId'],
            $data['packcode'],
            json_encode($data['licenseInfo'] ?? [], JSON_UNESCAPED_UNICODE),
            $data['order_date'] ?? date('Y-m-d H:i:s'),
            $data['customer_name'] ?? '',
            $data['customer_address'] ?? '',
            $data['customer_type'] ?? null,
            $data['taxcode'] ?? '',
            $data['identity_code'] ?? '',
            $data['tel'] ?? '',
            $data['email'] ?? '',
            $data['note'] ?? '',
            $data['amount'] ?? null,
            $data['payment_status'] ?? 0,
            $data['payment_tran_no'] ?? '',
            $data['payment_type'] ?? 0,
            $data['payment_date'] ?? null,
            $data['resource_status'] ?? 0,
            $data['partner_code'] ?? '',
            $data['employee_code'] ?? ''
        ];
        
        $affected = $this->db->execute($sql, $params);
        
        if ($affected > 0) {
            return $this->getById($orderId);
        }
        
        return null;
    }

    /**
     * Update order
     */
    public function update($id, $data) {
        $existing = $this->getById($id);
        if (!$existing) {
            throw new Exception("Order not found");
        }
        
        $fields = [];
        $params = [];
        
        $allowedFields = [
            'productId', 'packcode', 'licenseInfo', 'order_date', 'customer_name',
            'customer_address', 'customer_type', 'taxcode', 'identity_code', 'tel',
            'email', 'note', 'amount', 'payment_status', 'payment_tran_no', 'payment_type',
            'payment_date', 'resource_status', 'partner_code', 'employee_code'
        ];
        
        foreach ($allowedFields as $field) {
            if (array_key_exists($field, $data)) {
                if ($field === 'licenseInfo' && is_array($data[$field])) {
                    $fields[] = "{$field} = ?";
                    $params[] = json_encode($data[$field], JSON_UNESCAPED_UNICODE);
                } else {
                    $fields[] = "{$field} = ?";
                    $params[] = $data[$field];
                }
            }
        }
        
        if (empty($fields)) {
            throw new Exception("No valid fields to update");
        }
        
        $sql = "UPDATE order_info SET " . implode(', ', $fields) . " WHERE order_info_Id = ?";
        $params[] = $id;
        
        $affected = $this->db->execute($sql, $params);
        
        if ($affected > 0) {
            return $this->getById($id);
        }
        
        return null;
    }

    /**
     * Delete order
     */
    public function delete($id) {
        $sql = "DELETE FROM order_info WHERE order_info_Id = ?";
        return $this->db->execute($sql, [$id]);
    }

    /**
     * Duplicate order
     */
    public function duplicate($id) {
        $original = $this->getById($id);
        if (!$original) {
            throw new Exception("Original order not found");
        }
        
        // Remove ID and generate new order number
        unset($original['order_info_Id']);
        $original['orderno'] = $this->getNextOrderNo();
        
        return $this->create($original);
    }

    /**
     * Confirm payment
     */
    public function confirmPayment($id) {
        $data = [
            'payment_status' => 3, // Paid
            'payment_date' => date('Y-m-d H:i:s')
        ];
        
        return $this->update($id, $data);
    }

    /**
     * Provision resource
     */
    public function provisionResource($id) {
        $data = [
            'resource_status' => 1 // Provisioned
        ];
        
        return $this->update($id, $data);
    }

    /**
     * Export orders to CSV
     */
    public function exportToCSV($filters = []) {
        $where = '';
        $params = [];
        
        if (!empty($filters['search'])) {
            $where = "WHERE orderno LIKE ? OR productId LIKE ? OR customer_name LIKE ?";
            $searchTerm = "%{$filters['search']}%";
            $params = array_fill(0, 3, $searchTerm);
        }
        
        $sql = "SELECT * FROM order_info $where ORDER BY order_date DESC";
        return $this->db->select($sql, $params);
    }

    /**
     * Generate UUID for order ID
     */
    private function generateUUID() {
        return sprintf(
            '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
            mt_rand(0, 0xffff), mt_rand(0, 0xffff),
            mt_rand(0, 0xffff),
            mt_rand(0, 0x0fff) | 0x4000,
            mt_rand(0, 0x3fff) | 0x8000,
            mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
        );
    }
}

?>