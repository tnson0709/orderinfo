<?php
/**
 * class/Response.php
 * Purpose: Standardized API response format
 */

class Response {
    public static function json($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
        header('Access-Control-Allow-Headers: Content-Type, Authorization');
        
        echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
        exit;
    }

    public static function success($data = null, $message = 'Success') {
        self::json([
            'success' => true,
            'message' => $message,
            'data' => $data,
            'timestamp' => date('c')
        ]);
    }

    public static function error($message = 'Error', $statusCode = 400, $details = null) {
        self::json([
            'success' => false,
            'message' => $message,
            'details' => $details,
            'timestamp' => date('c')
        ], $statusCode);
    }

    public static function notFound($message = 'Resource not found') {
        self::error($message, 404);
    }

    public static function serverError($message = 'Internal server error') {
        self::error($message, 500);
    }
}
?>

